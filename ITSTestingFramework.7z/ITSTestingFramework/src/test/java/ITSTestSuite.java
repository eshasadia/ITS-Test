import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
@RunWith(Suite.class)
@Suite.SuiteClasses(
{

      
       NullCountTest.class,
       RowCountTest.class,
       SumAvgTest.class,
       MinMaxTest.class,
       RowCountTest.class,
       DistinctCountTest.class,
       HistoryTest.class,
       MinusTest.class,
       SurrogateKeyTest.class,
       RITest.class,
      //QueryGeneratorTest.class,
// 	   JobTypeParserTest.class,
// 	   ApplicationDatabaseStructureTest.class,
//       TeradataDataSourceTest.class,
//       LicenseControllerTest.class,
//       CustomTestScriptAutomatorTest.class,
      // DuplicateRecordSQLUtilTest.class,
      // DuplicateRecordTestAutomatorTest.class,	   
//	   DataSourceFactoryTest.class,
	   })
public class ITSTestSuite {
}
